<?php
require('head.php');



get_header();
?>
<?php get_header(); ?>
<?php require('getplugin.php'); ?>
<main class="main no-find">
  <h1 class="neon" data-text="[404 page]">404 page</h1>
  <p>お探しのページは削除されたか移動しました。</p>

</main>
<?php get_footer(); ?>

<?php get_footer(); ?>