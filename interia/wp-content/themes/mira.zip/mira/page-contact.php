<?php
require('head.php');



get_header();
?>
<main class="main contact-form">
  <div class="contact-top">
    <h2>CONTACT FORM</h2>
    
  </div>
  <?php the_content(); ?>
  <div class="privacy">
   
  </div>
</main>



<?php get_footer(); ?>