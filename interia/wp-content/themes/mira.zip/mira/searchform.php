<form method="get" id="searchform" action="<?php bloginfo('url'); ?>">
<input type="text" class="input-search" name="s" id="s" placeholder="SEARCH"/>
<button type="submit" class="submit-search"><img src="<?php echo getImg('search.png') ?>" alt="検索"></button>
</form>