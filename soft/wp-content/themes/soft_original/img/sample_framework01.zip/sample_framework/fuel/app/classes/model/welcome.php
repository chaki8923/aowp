<?php

namespace Model;

class Welcome extends \Model
{
    public static function get_results()
    {
        return 'レコードです';
    }
}

