<?php
return array(
  'crypto_key' => 'powWFErmgLDwgVgTr4GgkXBY',
  'crypto_iv' => '2KMTcQy4Qwy8C_k-2gIlUfgI',
  'crypto_hmac' => '6ggKTkMvYneMHC8Oh0tIwVg0',
);
