<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2016-06-21 14:22:42 --> Parsing Error - syntax error, unexpected '<' in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/template/head.php on line 8
ERROR - 2016-06-21 14:25:28 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/template/index.php on line 6
ERROR - 2016-06-21 17:21:58 --> Notice - Undefined variable: head in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/template/index.php on line 3
ERROR - 2016-06-21 19:26:30 --> Error - Could not find asset: user_img.png in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-06-21 19:53:07 --> Notice - Undefined property: Fuel\Core\Route::$method_param in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/home.php on line 12
ERROR - 2016-06-21 20:06:11 --> Notice - Undefined property: Fuel\Core\Route::$method_param in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/home.php on line 12
ERROR - 2016-06-21 21:45:42 --> Error - The requested view could not be found: index.php in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/view.php on line 477
ERROR - 2016-06-21 22:47:11 --> Fatal Error - Class 'Model\Welocome' not found in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/home.php on line 13
ERROR - 2016-06-21 22:48:06 --> Fatal Error - Class 'Model\Welecome' not found in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/home.php on line 13
ERROR - 2016-06-21 22:48:46 --> Fatal Error - Call to undefined method Model\Welcome::get_result() in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/home.php on line 13
