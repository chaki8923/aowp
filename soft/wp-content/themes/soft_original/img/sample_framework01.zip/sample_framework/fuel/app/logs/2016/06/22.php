<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2016-06-22 14:22:05 --> Notice - Undefined variable: signupform in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/auth/signup.php on line 9
ERROR - 2016-06-22 14:22:18 --> Notice - Undefined variable: signupform in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/auth/signup.php on line 9
ERROR - 2016-06-22 14:22:19 --> Notice - Undefined variable: signupform in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/auth/signup.php on line 9
ERROR - 2016-06-22 14:23:14 --> Notice - Undefined variable: signupform in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/auth/signup.php on line 9
ERROR - 2016-06-22 14:36:08 --> Error - "Email" is not a valid input type. in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/form/instance.php on line 217
ERROR - 2016-06-22 15:00:26 --> Notice - Use of undefined constant PASS_LENGTH_MIN - assumed 'PASS_LENGTH_MIN' in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/signup.php on line 24
ERROR - 2016-06-22 15:36:59 --> Notice - Undefined variable: error in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/signup.php on line 53
ERROR - 2016-06-22 15:37:29 --> Notice - Undefined variable: error in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/signup.php on line 53
ERROR - 2016-06-22 15:37:45 --> Notice - Undefined variable: error in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/signup.php on line 53
ERROR - 2016-06-22 15:37:46 --> Notice - Undefined variable: error in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/signup.php on line 53
WARNING - 2016-06-22 15:58:44 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 15:59:00 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 15:59:07 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 15:59:22 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 15:59:35 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 16:01:07 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 16:04:34 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 16:04:40 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 16:04:47 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 16:08:52 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 17:15:05 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 17:15:10 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 17:24:36 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 17:24:36 --> Notice - Undefined variable: formData in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/auth/signup.php on line 9
WARNING - 2016-06-22 17:24:44 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 17:26:11 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 17:26:23 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 17:26:30 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 17:26:46 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 18:22:32 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:22:32 --> Fatal Error - Class 'Auth' not found in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/signup.php on line 43
WARNING - 2016-06-22 18:24:54 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:24:54 --> Notice - Undefined index: username in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/signup.php on line 44
WARNING - 2016-06-22 18:25:55 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 18:26:18 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:26:18 --> Notice - Undefined index: dsn in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 480
WARNING - 2016-06-22 18:28:17 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:28:17 --> Notice - Undefined index: dsn in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 480
WARNING - 2016-06-22 18:28:31 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 18:28:34 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 18:28:49 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:28:49 --> Notice - Undefined index: dsn in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 480
WARNING - 2016-06-22 18:30:17 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:30:17 --> Warning - mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 131
WARNING - 2016-06-22 18:30:29 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:30:29 --> Notice - Undefined index: dsn in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 480
WARNING - 2016-06-22 18:35:03 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:35:03 --> Parsing Error - syntax error, unexpected ''username'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' in /Applications/MAMP/htdocs/sample_framework/fuel/app/config/db.php on line 15
WARNING - 2016-06-22 18:36:48 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:36:48 --> 2002 - SQLSTATE[HY000] [2002] Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 112
WARNING - 2016-06-22 18:47:47 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:47:47 --> Warning - mysqli::mysqli(): (HY000/2002): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 131
WARNING - 2016-06-22 18:49:46 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:49:46 --> Warning - mysqli::mysqli(): (HY000/2002): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 131
WARNING - 2016-06-22 18:53:04 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 18:53:04 --> Warning - mysqli::mysqli(): (HY000/2002): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 131
WARNING - 2016-06-22 20:24:05 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 20:24:05 --> 2002 - SQLSTATE[HY000] [2002] Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 112
WARNING - 2016-06-22 20:30:08 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 20:30:08 --> Warning - mysqli::mysqli(): (HY000/2002): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 131
WARNING - 2016-06-22 20:31:30 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 20:31:30 --> Warning - mysqli::mysqli(): (HY000/2002): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 131
WARNING - 2016-06-22 20:32:41 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-22 20:32:41 --> Warning - mysqli::mysqli(): (HY000/2002): Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 131
WARNING - 2016-06-22 20:38:26 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:38:41 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:40:52 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:40:54 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:42:03 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:42:06 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:42:30 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:42:38 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:42:55 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:43:06 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:43:39 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:43:45 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:44:07 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:44:35 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:45:09 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:45:20 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:45:44 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:47:47 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:48:15 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:49:57 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:50:38 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:50:59 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:51:27 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:51:57 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:52:10 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:53:06 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:53:30 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:53:42 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:53:44 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:54:04 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:55:09 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:55:50 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:56:52 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:57:15 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:57:25 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:57:40 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:57:56 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:58:03 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-22 20:58:10 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
