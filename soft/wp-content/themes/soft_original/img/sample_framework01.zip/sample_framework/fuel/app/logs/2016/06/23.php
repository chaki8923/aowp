<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-06-23 16:53:28 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 16:54:00 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 16:54:00 --> 1046 - No database selected [ SELECT * FROM `users` WHERE `username` = 'aiu' OR `email` = 'a@a.com' ] in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 292
WARNING - 2016-06-23 16:55:23 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 16:55:23 --> 42000 - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WI' at line 1 with query: "INSERT INTO users (username, password, email, group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WIFQprF6z8SfSloOLR5+bmxdd77QYvDIzDUbB9a4=', 'a@a.com', 1, 'a:0:{}', 0, '', 1466668523)" in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 253
WARNING - 2016-06-23 16:56:17 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 16:58:31 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 16:58:43 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 16:58:51 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 16:58:51 --> 42000 - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WI' at line 1 with query: "INSERT INTO users (username, password, email, group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WIFQprF6z8SfSloOLR5+bmxdd77QYvDIzDUbB9a4=', 'a@a.com', 1, 'a:0:{}', 0, '', 1466668731)" in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 253
WARNING - 2016-06-23 17:03:26 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 17:03:44 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 17:03:44 --> Fatal Error - Username, password or email address is not given, or email address is invalid in /Applications/MAMP/htdocs/sample_framework/fuel/packages/auth/classes/auth/login/simpleauth.php on line 239
WARNING - 2016-06-23 17:05:33 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 17:05:33 --> 42000 - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WI' at line 1 with query: "INSERT INTO users (username, password, email, group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WIFQprF6z8SfSloOLR5+bmxdd77QYvDIzDUbB9a4=', 'a@a.com', 1, 'a:0:{}', 0, '', 1466669133)" in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 253
WARNING - 2016-06-23 17:14:34 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 17:14:39 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 17:14:39 --> 42000 - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WI' at line 1 with query: "INSERT INTO users (username, password, email, group, profile_fields, last_login, login_hash, created_at) VALUES ('aiu', 'nZ8WIFQprF6z8SfSloOLR5+bmxdd77QYvDIzDUbB9a4=', 'a@a.com', 1, 'a:0:{}', 0, '', 1466669679)" in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/pdo/connection.php on line 253
WARNING - 2016-06-23 17:56:18 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 17:56:18 --> 1046 - No database selected [ SELECT * FROM `users` WHERE `username` = 'aiu' OR `email` = 'a@a.com' ] in /Applications/MAMP/htdocs/sample_framework/fuel/core/classes/database/mysqli/connection.php on line 292
WARNING - 2016-06-23 17:57:41 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 17:57:41 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 17:57:47 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 17:58:18 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 17:58:18 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 17:58:21 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:10:10 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 18:10:10 --> Warning - Email address already exists in /Applications/MAMP/htdocs/sample_framework/fuel/packages/auth/classes/auth/login/simpleauth.php on line 252
WARNING - 2016-06-23 18:10:16 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:10:27 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:10:28 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-06-23 18:10:28 --> Parsing Error - syntax error, unexpected ')' in /Applications/MAMP/htdocs/sample_framework/fuel/app/classes/controller/member/mypage.php on line 11
WARNING - 2016-06-23 18:10:43 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:11:46 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:12:09 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:13:01 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:13:38 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-06-23 18:13:47 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
