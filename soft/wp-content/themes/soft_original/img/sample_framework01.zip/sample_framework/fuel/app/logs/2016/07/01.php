<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-07-01 10:53:59 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 10:54:04 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 11:07:16 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 11:08:45 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 11:27:50 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 11:34:01 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 11:50:39 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 11:50:47 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 11:54:47 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 12:18:02 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-07-01 12:18:02 --> Notice - Undefined variable: formData in /Applications/MAMP/htdocs/sample_framework/fuel/app/views/auth/signup.php on line 4
WARNING - 2016-07-01 12:21:03 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 12:21:08 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 12:23:55 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 12:25:22 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 12:25:42 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
ERROR - 2016-07-01 12:25:42 --> 3 - Username already exists in /Applications/MAMP/htdocs/sample_framework/fuel/packages/auth/classes/auth/login/simpleauth.php on line 256
WARNING - 2016-07-01 12:26:34 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
WARNING - 2016-07-01 12:26:34 --> Fuel\Core\Fuel::init - The configured locale ja_JP.utf8 is not installed on your system.
