<div style="text-align: center;">
    <h1>マイページです。</h1>
</div>

