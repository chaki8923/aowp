<meta charset="utf-8">
<title>ホームページのタイトル</title>
<?= Asset::css('style.css') ?>